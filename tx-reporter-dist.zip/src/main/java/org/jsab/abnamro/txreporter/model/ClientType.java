package org.jsab.abnamro.txreporter.model;

/**
 *
 * @author JorgeLuis
 */
public enum ClientType
{
  CL,
  OTHER
}
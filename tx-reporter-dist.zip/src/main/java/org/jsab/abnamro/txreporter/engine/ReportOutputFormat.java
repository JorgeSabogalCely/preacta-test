package org.jsab.abnamro.txreporter.engine;

/**
 *
 * @author JorgeLuis
 */
public enum ReportOutputFormat
{
  CSV;
}
